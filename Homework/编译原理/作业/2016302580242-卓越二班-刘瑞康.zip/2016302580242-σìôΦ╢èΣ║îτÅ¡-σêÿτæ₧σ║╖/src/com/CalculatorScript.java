package com;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import javax.script.AbstractScriptEngine;
import javax.script.Bindings;
import javax.script.ScriptContext;
import javax.script.ScriptEngineFactory;
import javax.script.ScriptException;

public class CalculatorScript extends AbstractScriptEngine{

	enum CharType {DIGIT, LETTER, SYMBOL, SPACE, UNDEFINED};
	List<String> operators = Arrays.asList("+", "-", "*", "/", "=", "(", ")"); //other operators are not supported
	List<String> keywords = Arrays.asList("print", "sin"); //sin is reserved, but isn't implemented yet 

	//the process entry
	void run(String buffer) throws Exception
	{
		if(buffer.charAt(buffer.length()-1) != ';')
			throw new Exception("excepted \";\" missing");
		String sentences[] = buffer.split(";");
		
		for (String sentence : sentences) {
			preProcess(lex(sentence));
		}
	}
	
	//divide a string into several tokens and return the arraylist
	ArrayList<Token> lex(String str) throws Exception
	{
		ArrayList<Token> tokens = new ArrayList<Token>();
		while( !str.isEmpty() )
		{
			String currentToken = str.substring(0, 1);
			switch(checkType(currentToken.charAt(0)))
			{
			case DIGIT:
				boolean hasPoint = false;//the decimal point appears at most once
				int len = 0;
				char t;
				while(str.length() > len)
				{
					t = str.charAt(len);
					if(Character.isDigit(t))
					{
						++len;
					}
					else if(t=='.')
					{
						if(!hasPoint)
						{
							hasPoint = true;
							++len;
						}
						else
							throw new Exception("too much decimal point"); //wrong	
					}
					else
						break;
				}
				currentToken = str.substring(0,len);
				str = str.substring(len);
				tokens.add(new Token(TokenType.CONST, currentToken, Double.valueOf(currentToken)));
				break;
				
			case LETTER:
				int length = 0;
				CharType temp;
				while(str.length() > length)
				{
					temp = checkType(str.charAt(length));
					if(temp==CharType.LETTER ||temp==CharType.DIGIT)
					{
						++length;
					}
					else
						break;
				}
				currentToken = str.substring(0,length);
				str = str.substring(length);
				if(keywords.contains(currentToken))
					tokens.add(new Token(TokenType.KEYWORD, currentToken, 0.0));
				else
					tokens.add(new Token(TokenType.IDENTIFIER, currentToken, 0.0));
				break;
				
			case SYMBOL:
				str = str.substring(1);
				tokens.add(new Token(TokenType.OPERATOR, currentToken, 0.0));
				break;
				
			case SPACE:
				str = str.substring(1);
				tokens.add(new Token(TokenType.SPACE, currentToken, 0.0));
				break;
				
			case UNDEFINED:
				str = str.substring(1);
				tokens.add(new Token(TokenType.UNDEFINED, currentToken, 0.0));
				break;
			}
		}
		return tokens;
	}

	//according to the first token, determine the basic operation to execute
	void preProcess(ArrayList<Token> tokens) throws Exception
	{
		if(tokens.get(0).type == TokenType.KEYWORD)
		{
			if(tokens.get(0).name.equals("print"))
				if(tokens.get(1).name.equals("(") && tokens.get(tokens.size()-1).name.equals(")"))
				{
					getContext().getWriter().write(String.valueOf(process(tokens, 2, tokens.size()-1))+"\n");
				}
				else
					throw new Exception("Wrong input");
		}
		else if(tokens.get(0).type == TokenType.IDENTIFIER)
		{
			int begin = 0;
			for (Token token : tokens) {
				++begin;
				if(token.name.equals("="))
					break;
			}
			double value = process(tokens, begin, tokens.size());
			put(tokens.get(0).name, value);
		}
	}
	
	double process(ArrayList<Token> tokens, int begin, int end) throws Exception
	{
		Stack<Double> numbers = new Stack<Double>();
		Stack<Operator> ops = new Stack<Operator>();
		
		int length = end - begin;
		for(int i = 0; i < length; ++i)
		{
			Token temp = tokens.get(begin + i);
			switch(temp.type)
			{
			case IDENTIFIER:
				numbers.push(Double.parseDouble(getContext().getAttribute(temp.name).toString()));
				break;
			case CONST:
				numbers.push(temp.value);
				break;
			case SPACE:
				break;
			case OPERATOR:
				Operator op = new Operator(temp.name);
				while(!ops.empty() && (ops.peek().compareTo(op) >= 0))
				{
					Operator op2 = ops.pop();
					double b = numbers.pop();
					double a = numbers.pop();
					numbers.push(calculate(a, b, op2.op));
				}
				if(temp.name.equals(")"))
					ops.pop();
				else
					ops.push(op);
				break;
			default:
				throw new Exception("invalid input sentence");
			}
		}
		
		while(!ops.empty())
		{
			double b = numbers.pop();
			double a = numbers.pop();
			numbers.push(calculate(a, b, ops.pop().op));
		}
		
		return numbers.pop();
	}

	//check the type of the current char
	CharType checkType(char c)
	{
		if(Character.isDigit(c))
			return CharType.DIGIT;
		else if(Character.isAlphabetic(c))
			return CharType.LETTER;
		else if(operators.contains(String.valueOf(c)))
			return CharType.SYMBOL;
		else if(c==' ')
		{
			return CharType.SPACE;
		}
		else 
			return CharType.UNDEFINED;
	}

	//according to the op, do the operation
	double calculate(double a, double b, String op) throws Exception
	{
		switch(op)
		{
		case "+": return a+b;
		case "-": return a-b;
		case "*": return a*b;
		case "/":
			if(b==0.0)
				throw new Exception("try to divide a double by 0");
			return a/b;
		default: return 0.0;
		}
	}
	

	@Override
	public Object eval(String script, ScriptContext context) throws ScriptException {
		try {
			run(script);
		}
		catch(Exception e)
		{
			throw new ScriptException("666");
		}
		return null;
	}


	@Override
	public Object eval(Reader reader, ScriptContext context) throws ScriptException {
		return null;
	}

	@Override
	public Bindings createBindings() {
		return null;
	}

	@Override
	public ScriptEngineFactory getFactory() {
		return new CalculatorScriptEngineFactory();
	}
}


