package com;

//help to calculate the infix expression
class Operator implements Comparable<Operator>
{
	String op;
	int inputPrec;
	int stackPrec;
	
	public Operator(String o)
	{
		op = o;
		switch(op)
		{
		case "+":
		case "-":
			inputPrec = stackPrec = 1;
			break;
		case "*":
		case "/":
			inputPrec = stackPrec = 2;
			break;
		case "(":
			inputPrec = 3;
			stackPrec = -1;
			break;
		case ")":
			inputPrec = stackPrec = 0;
			break;
		}
	}
	
	@Override
	public int compareTo(Operator o) {
		if( stackPrec < o.inputPrec)
			return -1;
		else if( stackPrec == o.inputPrec)
			return 0;
		else
			return 1;
	}
		
}
