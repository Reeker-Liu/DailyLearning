package com;

enum TokenType {IDENTIFIER, CONST, OPERATOR, KEYWORD, SPACE, UNDEFINED};
class Token
{
	public TokenType type;
	public String name;
	public Double value;
	public Token(TokenType t, String n, Double v)
	{
		type = t;
		name = n;
		value = v;
	}
}