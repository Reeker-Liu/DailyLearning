package com;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineFactory;

public class CalculatorScriptEngineFactory implements ScriptEngineFactory{

	public CalculatorScriptEngineFactory() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getEngineName() {
		// TODO Auto-generated method stub
		return "Calculator Script Engine";
	}

	@Override
	public String getEngineVersion() {
		// TODO Auto-generated method stub
		return "1.0";
	}

	@Override
	public List<String> getExtensions() {
		// TODO Auto-generated method stub
		return Arrays.asList("in", "calc");
	}

	@Override
	public List<String> getMimeTypes() {
		// TODO Auto-generated method stub
		return Arrays.asList("text/calculatorscript", "application/calculatorscript");
	}

	@Override
	public List<String> getNames() {
		// TODO Auto-generated method stub
		return Arrays.asList("CalculatorScript", "Calculator", "calculator", "Calc", "calc");
	}

	@Override
	public String getLanguageName() {
		// TODO Auto-generated method stub
		return "Calculator Script";
	}

	@Override
	public String getLanguageVersion() {
		// TODO Auto-generated method stub
		return "1.0";
	}

	@Override
	public Object getParameter(String key) {
		if (Objects.equals(key, "javax.script.engine")) {
	        return this.getEngineName();
	    } else if (Objects.equals(key, "javax.script.engine_version")) {
	        return this.getEngineVersion();
	    } else if (Objects.equals(key, "javax.script.name")) {
	        return this.getNames();
	    } else if (Objects.equals(key, "javax.script.language")) {
	        return this.getLanguageName();
	    } else {
	        return Objects.equals(key, "javax.script.language_version") ? this.getLanguageVersion() : null;
	    }
	}

	@Override
	public String getMethodCallSyntax(String obj, String m, String... args) {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getOutputStatement(String toDisplay) {
		// TODO Auto-generated method stub
		return "print(" + toDisplay + ");";
	}

	@Override
	public String getProgram(String... statements) {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public ScriptEngine getScriptEngine() {
		return new CalculatorScript();
	}
}


